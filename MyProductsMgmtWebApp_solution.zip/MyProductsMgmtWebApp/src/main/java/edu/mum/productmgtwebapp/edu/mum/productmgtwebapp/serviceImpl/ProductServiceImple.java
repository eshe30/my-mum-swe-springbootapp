package edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.serviceImpl;

import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.model.Product;
import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.repository.ProductRepository;
import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.service.ProductServive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductServiceImple implements ProductServive {

    @Autowired
    ProductRepository productRepository;

    @Override
    public Product addProduct(Product product) {

        return productRepository.save(product);
    }

    @Override
    public List<Product> getAllProducts() {
        return (List<Product>) productRepository.findAll();
    }

    @Override
    public Product getProductById(Long id) {
        Optional<Product> product=productRepository.findById(id);
        return product.orElse(null);
    }

    @Override
    public void deleteProduct(Long id) {
      productRepository.deleteById(id);
    }
}
