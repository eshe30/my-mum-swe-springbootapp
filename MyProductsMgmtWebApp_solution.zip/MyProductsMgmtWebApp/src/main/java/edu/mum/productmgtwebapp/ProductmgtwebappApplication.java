package edu.mum.productmgtwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan("edu.mum.productmgtwebapp")
public class ProductmgtwebappApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductmgtwebappApplication.class, args);
    }
}
