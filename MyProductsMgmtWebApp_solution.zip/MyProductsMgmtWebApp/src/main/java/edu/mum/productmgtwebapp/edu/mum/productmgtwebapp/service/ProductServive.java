package edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.service;

import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.model.Product;

import java.util.List;
import java.util.Optional;

public interface ProductServive {

    Product addProduct(Product product);
    List<Product> getAllProducts();

    Product getProductById(Long id);
    void deleteProduct(Long id);
}
