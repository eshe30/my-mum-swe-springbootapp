package edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.controller;

import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.model.Product;
import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.service.ProductServive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
public class ProductController {

    @Autowired
    ProductServive productServive;

    @GetMapping(value = "/product")
    public String addProductForm(Model model) {
        model.addAttribute("product", new Product());

        return "product/edit";
    }


    @GetMapping(value = "/products")
    public String getProducts(Model model) {

        model.addAttribute("products", productServive.getAllProducts());
        return "product/list";
    }


    @PostMapping(value = "/product")
    public String addProduct(@Valid @ModelAttribute("product") Product product, BindingResult bindingResult, Model model) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getAllErrors());
            return "product/edit";
        }

        product = productServive.addProduct(product);
        return "redirect:/products";
    }

    @GetMapping(value = "/product/delete/{id}")
    public String deleteProduct(@PathVariable("id") Long id, Model model){
        productServive.deleteProduct(id);
        return "redirect:/products";
    }

    @GetMapping(value = "/product/{id}")
    public String updateProduct(@PathVariable("id") Long id, Model model){
       model.addAttribute("product", productServive.getProductById(id));

        return "product/edit";
    }




}
