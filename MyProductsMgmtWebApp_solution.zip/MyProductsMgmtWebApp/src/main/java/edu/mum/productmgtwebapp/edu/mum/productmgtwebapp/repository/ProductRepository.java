package edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.repository;

import edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.model.Product;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {

}
