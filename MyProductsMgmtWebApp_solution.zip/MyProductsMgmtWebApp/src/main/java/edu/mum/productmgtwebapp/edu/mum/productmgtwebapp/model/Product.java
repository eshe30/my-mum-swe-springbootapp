package edu.mum.productmgtwebapp.edu.mum.productmgtwebapp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long pid;
    //@NotEmpty(message = "Product Number should not be empty")
    private Long productNumber;
    //@NotEmpty(message = "Product Name should not be empty")
    private String name;

    private float unitPrice;
    //@NotEmpty(message = "Date Must Have a value")
    private Date dateMfd;

    public Product(){

    }

    public Product(Long productNumber, String name, float unitPrice, Date dateMfd) {
        this.productNumber = productNumber;
        this.name = name;
        this.unitPrice = unitPrice;
        this.dateMfd = dateMfd;
    }

    public long getPid() {
        return pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public Long getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(long productNumber) {
        this.productNumber = productNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(float unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Date getDateMfd() {
        return dateMfd;
    }

    public void setDateMfd(Date dateMfd) {
        this.dateMfd = dateMfd;
    }

   /* @Override
    public String toString(){
        String string="";
        string+= "productNumber "+ productNumber+ ", name "+ name+ ", unit Price "+ unitPrice+ ", manufacturdeDate "+dateMfd;
        return string;
    }*/
}
